module input_register (
    input wire clk,
    input wire reset,
    input wire START,
    input wire [4:0] X_in,
    output reg [4:0] X_reg = 5'b00000   // power-up value (removes red/X at time 0)
);

always @(posedge clk or posedge reset) begin
    if (reset)
        X_reg <= 5'b00000;
    else if (START)
        X_reg <= X_in;
end

endmodule