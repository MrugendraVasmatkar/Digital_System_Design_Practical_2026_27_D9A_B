`timescale 1ns / 1ps

module top_module_tb;

reg clk = 1'b0;
reg reset = 1'b1;
reg START = 1'b0;
reg ACK = 1'b0;
reg [4:0] X_in = 5'd0;

wire fib_led;
wire non_fib_led;
wire [1:0] state;

integer passed = 0;
integer failed = 0;
integer i;

top_module DUT (
    .clk(clk),
    .reset(reset),
    .START(START),
    .ACK(ACK),
    .X_in(X_in),
    .fib_led(fib_led),
    .non_fib_led(non_fib_led),
    .state(state)
);

// 100 MHz clock (10 ns period)
always #5 clk = ~clk;

// Fibonacci number checker
function is_fib;
    input [4:0] v;
    begin
        is_fib = (v == 5'd0)  ||
                 (v == 5'd1)  ||
                 (v == 5'd2)  ||
                 (v == 5'd3)  ||
                 (v == 5'd5)  ||
                 (v == 5'd8)  ||
                 (v == 5'd13) ||
                 (v == 5'd21);
    end
endfunction

// Test individual input
task test_input;
    input [4:0] v;
    reg exp;
    begin
        exp = is_fib(v);

        // Apply input and START pulse
        @(negedge clk);
        X_in = v;
        START = 1'b1;

        @(negedge clk);
        START = 1'b0;

        // Check FSM output
        @(posedge clk);
        #1;

        if ((fib_led === exp) &&
            (non_fib_led === ~exp) &&
            (state === (exp ? 2'b01 : 2'b10))) begin

            $display(
                "PASS: Input=%0d | FIB_LED=%b | NON_FIB_LED=%b | STATE=%b",
                v, fib_led, non_fib_led, state
            );

            passed = passed + 1;
        end
        else begin

            $display(
                "FAIL: Input=%0d | FIB_LED=%b | NON_FIB_LED=%b | STATE=%b",
                v, fib_led, non_fib_led, state
            );

            failed = failed + 1;
        end

        // Apply ACK to return FSM to IDLE
        @(negedge clk);
        ACK = 1'b1;

        @(negedge clk);
        ACK = 1'b0;

        @(posedge clk);
        #1;

        if ((state === 2'b00) &&
            (fib_led === 1'b0) &&
            (non_fib_led === 1'b0)) begin

            passed = passed + 1;
            $display("PASS: ACK returned FSM to IDLE");
        end
        else begin

            failed = failed + 1;
            $display("FAIL: FSM did not return to IDLE");
        end
    end
endtask

// Main test sequence
initial begin

    $display("--------------------------------");
    $display("EXTENDED FIBONACCI DETECTOR");
    $display("COMPLETE SYSTEM TESTBENCH");
    $display("--------------------------------");

    // Initial reset
    repeat (2) @(posedge clk);
    @(negedge clk);
    reset = 1'b0;

    // Test all 32 possible 5-bit inputs
    for (i = 0; i < 32; i = i + 1) begin
        test_input(i[4:0]);
    end

    // Asynchronous reset test
    @(negedge clk);
    X_in = 5'd8;
    START = 1'b1;

    @(negedge clk);
    START = 1'b0;

    @(posedge clk);
    #1;

    // Assert asynchronous reset
    reset = 1'b1;
    #2;

    if ((state === 2'b00) &&
        (fib_led === 1'b0) &&
        (non_fib_led === 1'b0)) begin

        passed = passed + 1;
        $display("PASS: Asynchronous RESET returned FSM to IDLE");
    end
    else begin

        failed = failed + 1;
        $display("FAIL: Asynchronous RESET test failed");
    end

    // Safely release reset
    @(negedge clk);
    reset = 1'b0;

    // Final results
    $display("");
    $display("--------------------------------");
    $display("TOTAL PASSED = %0d", passed);
    $display("TOTAL FAILED = %0d", failed);
    $display("--------------------------------");

    if (failed == 0)
        $display("OVERALL RESULT: ALL TESTS PASSED");
    else
        $display("OVERALL RESULT: TESTS FAILED");

    $finish;
end

endmodule