`timescale 1ns / 1ps

module fibonacci_comparator_tb;

reg [4:0] X;
wire F;

reg expected;
integer i;
integer pass_count;
integer fail_count;

fibonacci_comparator uut (
    .X(X),
    .F(F)
);

initial begin

    pass_count = 0;
    fail_count = 0;

    $display("======================================");
    $display("5-BIT EXTENDED FIBONACCI DETECTOR");
    $display("======================================");

    for (i = 0; i < 32; i = i + 1) begin

        X = i;

        case (i)
            0, 1, 2, 3, 5, 8, 13, 21:
                expected = 1'b1;

            default:
                expected = 1'b0;
        endcase

        #10;

        if (F === expected) begin
            $display("PASS | X = %d | F = %b", X, F);
            pass_count = pass_count + 1;
        end
        else begin
            $display("FAIL | X = %d | Expected = %b | Actual = %b",
                     X, expected, F);
            fail_count = fail_count + 1;
        end

    end

    $display("======================================");
    $display("TOTAL TESTS : %d", 32);
    $display("PASSED      : %d", pass_count);
    $display("FAILED      : %d", fail_count);
    $display("======================================");

    $finish;

end

endmodule