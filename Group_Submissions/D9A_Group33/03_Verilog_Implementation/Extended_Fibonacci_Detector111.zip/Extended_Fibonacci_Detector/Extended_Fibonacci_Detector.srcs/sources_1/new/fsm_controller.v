module fsm_controller (
    input wire clk,
    input wire reset,
    input wire START,
    input wire ACK,
    input wire fib_detect,

    output reg fib_led,
    output reg non_fib_led,
    output reg [1:0] state = 2'b00   // power-up value = IDLE (removes red/X at time 0)
);

// STATE ENCODING
localparam IDLE    = 2'b00;
localparam FIB     = 2'b01;
localparam NON_FIB = 2'b10;

reg [1:0] next_state;


// =================================
// 1. STATE REGISTER
// =================================

always @(posedge clk or posedge reset) begin

    if (reset)
        state <= IDLE;

    else
        state <= next_state;

end


// =================================
// 2. NEXT STATE LOGIC
// =================================

always @(*) begin

    next_state = state;

    case (state)

        IDLE: begin

            if (START) begin

                if (fib_detect)
                    next_state = FIB;

                else
                    next_state = NON_FIB;

            end

            else
                next_state = IDLE;

        end


        FIB: begin

            if (ACK)
                next_state = IDLE;

            else
                next_state = FIB;

        end


        NON_FIB: begin

            if (ACK)
                next_state = IDLE;

            else
                next_state = NON_FIB;

        end


        default: begin
            next_state = IDLE;
        end

    endcase

end


// =================================
// 3. MOORE OUTPUT LOGIC
// =================================

always @(*) begin

    fib_led = 1'b0;
    non_fib_led = 1'b0;

    case (state)

        IDLE: begin
            fib_led = 1'b0;
            non_fib_led = 1'b0;
        end


        FIB: begin
            fib_led = 1'b1;
            non_fib_led = 1'b0;
        end


        NON_FIB: begin
            fib_led = 1'b0;
            non_fib_led = 1'b1;
        end


        default: begin
            fib_led = 1'b0;
            non_fib_led = 1'b0;
        end

    endcase

end

endmodule