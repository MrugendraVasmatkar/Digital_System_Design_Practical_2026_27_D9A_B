module fibonacci_comparator (
    input wire [4:0] X,
    output wire F
);

assign F = (X == 5'd0)  ||
           (X == 5'd1)  ||
           (X == 5'd2)  ||
           (X == 5'd3)  ||
           (X == 5'd5)  ||
           (X == 5'd8)  ||
           (X == 5'd13) ||
           (X == 5'd21);

endmodule