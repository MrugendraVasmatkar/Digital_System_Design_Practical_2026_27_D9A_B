module top_module (
    input wire clk,
    input wire reset,
    input wire START,
    input wire ACK,
    input wire [4:0] X_in,

    output wire fib_led,
    output wire non_fib_led,
    output wire [1:0] state
);

wire [4:0] X_reg;
wire fib_detect;
reg start_delayed = 1'b0;   // power-up value (removes red/X at time 0)

// 1. Input Register
input_register U1 (
    .clk(clk),
    .reset(reset),
    .START(START),
    .X_in(X_in),
    .X_reg(X_reg)
);

// 2. Fibonacci Comparator
fibonacci_comparator U2 (
    .X(X_reg),
    .F(fib_detect)
);

// 3. Delay START by one clock cycle
always @(posedge clk or posedge reset) begin
    if (reset)
        start_delayed <= 1'b0;
    else
        start_delayed <= START;
end

// 4. Moore FSM Controller
fsm_controller U3 (
    .clk(clk),
    .reset(reset),
    .START(start_delayed),
    .ACK(ACK),
    .fib_detect(fib_detect),
    .fib_led(fib_led),
    .non_fib_led(non_fib_led),
    .state(state)
);

endmodule